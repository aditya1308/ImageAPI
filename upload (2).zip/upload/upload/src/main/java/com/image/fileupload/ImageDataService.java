package com.image.fileupload;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Optional;

@Service
public class ImageDataService {

    @Autowired
    private ImageDataRepository imageDataRepository;

    public ImageUploadResponse uploadImage(MultipartFile file) throws IOException {
    	
    	ImageData imageData = new ImageData();
    	imageData.setName(file.getOriginalFilename());
    	imageData.setType(file.getContentType());
    	imageData.setImageData(ImageUtil.compressImage(file.getBytes()));

    	imageDataRepository.save(imageData);

//        imageDataRepository.save(ImageData.builder()
//                .name(file.getOriginalFilename())
//                .type(file.getContentType())
//                .imageData(ImageUtil.compressImage(file.getBytes())).build());

        return new ImageUploadResponse("Image uploaded successfully: " +
                file.getOriginalFilename());

    }

    public ImageData getInfoByImageByName(String name) {
        Optional<ImageData> dbImageOptional = imageDataRepository.findByName(name);
        
        if (dbImageOptional.isPresent()) {
            ImageData dbImage = dbImageOptional.get();
            ImageData imageData = new ImageData();
            imageData.setName(dbImage.getName());
            imageData.setType(dbImage.getType());
            imageData.setImageData(ImageUtil.decompressImage(dbImage.getImageData()));
            return imageData;
        } else {
            return null; // or handle the case when the image is not found
        }
        

//        return ImageData.builder()
//                .name(dbImage.get().getName())
//                .type(dbImage.get().getType())
//                .imageData(ImageUtil.decompressImage(dbImage.get().getImageData())).build();

    }

    public byte[] getImage(String name) {
        Optional<ImageData> dbImage = imageDataRepository.findByName(name);
        byte[] image = ImageUtil.decompressImage(dbImage.get().getImageData());
        return image;
    }


}
