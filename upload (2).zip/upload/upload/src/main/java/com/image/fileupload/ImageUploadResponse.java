package com.image.fileupload;

public class ImageUploadResponse {

	public ImageUploadResponse(String string) {
		// TODO Auto-generated constructor stub
	}

}
